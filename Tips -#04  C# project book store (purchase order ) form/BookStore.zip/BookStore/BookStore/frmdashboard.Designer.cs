﻿
namespace BookStore
{
    partial class frmdashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmdashboard));
            this._styleform = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this._menu = new System.Windows.Forms.MenuStrip();
            this._file_sub = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_user_account = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_supply_info = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_product_info = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_author_info = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_purchaseorder = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_reports = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_logout = new System.Windows.Forms.ToolStripMenuItem();
            this._authorize_sub = new System.Windows.Forms.ToolStripMenuItem();
            this._tools_sub = new System.Windows.Forms.ToolStripMenuItem();
            this._setting_sub = new System.Windows.Forms.ToolStripMenuItem();
            this._about_sub = new System.Windows.Forms.ToolStripMenuItem();
            this.ss_auth_purchaseorder = new System.Windows.Forms.ToolStripMenuItem();
            this._menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // _styleform
            // 
            this._styleform.ButtonSpecs.FormClose.ColorMap = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this._styleform.ButtonSpecs.FormClose.Edge = ComponentFactory.Krypton.Toolkit.PaletteRelativeEdgeAlign.Far;
            this._styleform.ButtonSpecs.FormClose.Image = ((System.Drawing.Image)(resources.GetObject("_styleform.ButtonSpecs.FormClose.Image")));
            this._styleform.ButtonSpecs.FormClose.ImageStates.ImageNormal = ((System.Drawing.Image)(resources.GetObject("_styleform.ButtonSpecs.FormClose.ImageStates.ImageNormal")));
            this._styleform.ButtonSpecs.FormClose.ImageStates.ImagePressed = ((System.Drawing.Image)(resources.GetObject("_styleform.ButtonSpecs.FormClose.ImageStates.ImagePressed")));
            this._styleform.ButtonSpecs.FormClose.ImageStates.ImageTracking = ((System.Drawing.Image)(resources.GetObject("_styleform.ButtonSpecs.FormClose.ImageStates.ImageTracking")));
            this._styleform.ButtonSpecs.FormClose.Style = ComponentFactory.Krypton.Toolkit.PaletteButtonStyle.ButtonSpec;
            this._styleform.ButtonSpecs.FormClose.ToolTipTitle = "Close";
            this._styleform.ButtonSpecs.FormMin.Image = ((System.Drawing.Image)(resources.GetObject("_styleform.ButtonSpecs.FormMin.Image")));
            this._styleform.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this._styleform.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this._styleform.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this._styleform.FormStyles.FormMain.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this._styleform.FormStyles.FormMain.StateCommon.Border.Rounding = 12;
            this._styleform.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this._styleform.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this._styleform.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            // 
            // _menu
            // 
            this._menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this._menu.Font = new System.Drawing.Font("Segoe UI", 9F);
            this._menu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this._menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this._menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._file_sub,
            this._authorize_sub,
            this._tools_sub,
            this._setting_sub,
            this._about_sub});
            this._menu.Location = new System.Drawing.Point(0, 0);
            this._menu.Name = "_menu";
            this._menu.Size = new System.Drawing.Size(1184, 28);
            this._menu.TabIndex = 1;
            // 
            // _file_sub
            // 
            this._file_sub.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ss_user_account,
            this.ss_supply_info,
            this.ss_product_info,
            this.ss_author_info,
            this.ss_purchaseorder,
            this.ss_reports,
            this.ss_logout});
            this._file_sub.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._file_sub.Image = ((System.Drawing.Image)(resources.GetObject("_file_sub.Image")));
            this._file_sub.Name = "_file_sub";
            this._file_sub.Size = new System.Drawing.Size(63, 24);
            this._file_sub.Text = "&file";
            // 
            // ss_user_account
            // 
            this.ss_user_account.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ss_user_account.Image = ((System.Drawing.Image)(resources.GetObject("ss_user_account.Image")));
            this.ss_user_account.Name = "ss_user_account";
            this.ss_user_account.Size = new System.Drawing.Size(221, 26);
            this.ss_user_account.Text = "User Account";
            this.ss_user_account.Click += new System.EventHandler(this.ss_user_account_Click);
            // 
            // ss_supply_info
            // 
            this.ss_supply_info.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_supply_info.Image = ((System.Drawing.Image)(resources.GetObject("ss_supply_info.Image")));
            this.ss_supply_info.Name = "ss_supply_info";
            this.ss_supply_info.Size = new System.Drawing.Size(221, 26);
            this.ss_supply_info.Text = "Supply info";
            this.ss_supply_info.Click += new System.EventHandler(this.ss_supply_info_Click);
            // 
            // ss_product_info
            // 
            this.ss_product_info.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_product_info.Image = ((System.Drawing.Image)(resources.GetObject("ss_product_info.Image")));
            this.ss_product_info.Name = "ss_product_info";
            this.ss_product_info.Size = new System.Drawing.Size(221, 26);
            this.ss_product_info.Text = "Product Info";
            this.ss_product_info.Click += new System.EventHandler(this.ss_product_info_Click);
            // 
            // ss_author_info
            // 
            this.ss_author_info.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_author_info.Image = ((System.Drawing.Image)(resources.GetObject("ss_author_info.Image")));
            this.ss_author_info.Name = "ss_author_info";
            this.ss_author_info.Size = new System.Drawing.Size(221, 26);
            this.ss_author_info.Text = "Author Info";
            // 
            // ss_purchaseorder
            // 
            this.ss_purchaseorder.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_purchaseorder.Image = ((System.Drawing.Image)(resources.GetObject("ss_purchaseorder.Image")));
            this.ss_purchaseorder.Name = "ss_purchaseorder";
            this.ss_purchaseorder.Size = new System.Drawing.Size(221, 26);
            this.ss_purchaseorder.Text = "Purchase order";
            this.ss_purchaseorder.Click += new System.EventHandler(this.ss_purchaseorder_Click);
            // 
            // ss_reports
            // 
            this.ss_reports.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_reports.Image = ((System.Drawing.Image)(resources.GetObject("ss_reports.Image")));
            this.ss_reports.Name = "ss_reports";
            this.ss_reports.Size = new System.Drawing.Size(221, 26);
            this.ss_reports.Text = "Reports";
            // 
            // ss_logout
            // 
            this.ss_logout.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_logout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ss_logout.Image = ((System.Drawing.Image)(resources.GetObject("ss_logout.Image")));
            this.ss_logout.Name = "ss_logout";
            this.ss_logout.Size = new System.Drawing.Size(221, 26);
            this.ss_logout.Text = "Logout";
            this.ss_logout.Click += new System.EventHandler(this.ss_logout_Click);
            // 
            // _authorize_sub
            // 
            this._authorize_sub.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ss_auth_purchaseorder});
            this._authorize_sub.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this._authorize_sub.Image = ((System.Drawing.Image)(resources.GetObject("_authorize_sub.Image")));
            this._authorize_sub.Name = "_authorize_sub";
            this._authorize_sub.Size = new System.Drawing.Size(107, 24);
            this._authorize_sub.Text = "Authorize";
            // 
            // _tools_sub
            // 
            this._tools_sub.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this._tools_sub.Image = ((System.Drawing.Image)(resources.GetObject("_tools_sub.Image")));
            this._tools_sub.Name = "_tools_sub";
            this._tools_sub.Size = new System.Drawing.Size(74, 24);
            this._tools_sub.Text = "Tools";
            // 
            // _setting_sub
            // 
            this._setting_sub.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this._setting_sub.Image = ((System.Drawing.Image)(resources.GetObject("_setting_sub.Image")));
            this._setting_sub.Name = "_setting_sub";
            this._setting_sub.Size = new System.Drawing.Size(87, 24);
            this._setting_sub.Text = "Setting";
            // 
            // _about_sub
            // 
            this._about_sub.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this._about_sub.Image = ((System.Drawing.Image)(resources.GetObject("_about_sub.Image")));
            this._about_sub.Name = "_about_sub";
            this._about_sub.Size = new System.Drawing.Size(81, 24);
            this._about_sub.Text = "About";
            // 
            // ss_auth_purchaseorder
            // 
            this.ss_auth_purchaseorder.Font = new System.Drawing.Font("Courier Prime", 12F, System.Drawing.FontStyle.Italic);
            this.ss_auth_purchaseorder.Image = ((System.Drawing.Image)(resources.GetObject("ss_auth_purchaseorder.Image")));
            this.ss_auth_purchaseorder.Name = "ss_auth_purchaseorder";
            this.ss_auth_purchaseorder.Size = new System.Drawing.Size(221, 26);
            this.ss_auth_purchaseorder.Text = "Purchase order";
            this.ss_auth_purchaseorder.Click += new System.EventHandler(this.ss_auth_purchaseorder_Click);
            // 
            // frmdashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this._menu);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmdashboard";
            this.Palette = this._styleform;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmdashboard";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmdashboard_FormClosed);
            this.Load += new System.EventHandler(this.frmdashboard_Load);
            this._menu.ResumeLayout(false);
            this._menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette _styleform;
        private System.Windows.Forms.MenuStrip _menu;
        private System.Windows.Forms.ToolStripMenuItem ss_user_account;
        private System.Windows.Forms.ToolStripMenuItem _tools_sub;
        private System.Windows.Forms.ToolStripMenuItem _setting_sub;
        private System.Windows.Forms.ToolStripMenuItem _about_sub;
        public System.Windows.Forms.ToolStripMenuItem _file_sub;
        private System.Windows.Forms.ToolStripMenuItem ss_reports;
        private System.Windows.Forms.ToolStripMenuItem ss_product_info;
        private System.Windows.Forms.ToolStripMenuItem ss_supply_info;
        private System.Windows.Forms.ToolStripMenuItem ss_author_info;
        private System.Windows.Forms.ToolStripMenuItem ss_logout;
        private System.Windows.Forms.ToolStripMenuItem ss_purchaseorder;
        private System.Windows.Forms.ToolStripMenuItem _authorize_sub;
        private System.Windows.Forms.ToolStripMenuItem ss_auth_purchaseorder;
    }
}